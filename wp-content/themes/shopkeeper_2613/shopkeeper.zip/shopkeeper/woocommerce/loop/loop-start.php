<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */
 
global $shopkeeper_theme_options;
?>

<div class="row">
	<div class="large-12 columns">
		<ul id="products-grid" class="row products products-grid <?php shopkeeper_loop_columns_class(); ?>">