//@prepros-prepend ../inc/foundation/js/foundation.js
//@prepros-prepend vendor/isotope.pkgd.min.js
//@prepros-prepend vendor/fresco.js
//@prepros-prepend vendor/imagesloaded.js
//@prepros-prepend vendor/easyzoom.js
//@prepros-prepend vendor/jquery.touchSwipe.min.js

//@prepros-prepend vendor/swiper.js
//@prepros-prepend vendor/select2.min.js
//@prepros-prepend vendor/jquery.nanoscroller.min.js
//@prepros-prepend vendor/jquery.stellar.min.js
//@prepros-prepend vendor/velocity.min.js

//@prepros-prepend components/gutenberg.js

//@prepros-prepend components/scripts.js
//@prepros-prepend components/wp-blog-ajax.js

//@prepros-prepend components/wc-product-gallery.js
//@prepros-prepend components/wc-quickview.js
//@prepros-prepend components/wc-minicart.js
//@prepros-prepend components/wc-products-ajax.js
//@prepros-prepend components/wc-easyzoom.js
//@prepros-prepend components/wc-product-navigation.js
//@prepros-prepend components/wc-product-infos.js
//@prepros-prepend components/wc-product-ratings.js
//@prepros-prepend components/wc-product-quantity.js
//@prepros-prepend components/wc-counters.js
//@prepros-prepend components/wc-catalog-mode.js
//@prepros-prepend components/wc-notifications.js

//@prepros-prepend components/shortcode-slider.js

//@prepros-prepend tests.js